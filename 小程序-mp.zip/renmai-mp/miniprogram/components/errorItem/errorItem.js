// components/errorItem/errorItem.js
const $api = require('../../utils/request.js').request;
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    errorInfo: Object
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    goDetail() {
      console.log(this.properties.errorInfo);
      let errorInfo = this.properties.errorInfo;
      $api('GET', `/rmy/faultHandle/selectByfaultRecordId?faultRecordId=${errorInfo.faultRecordId}`).then(res => {
        if(this.properties.errorInfo.handleStatus === "已处理") {
          errorInfo = res.data.obj;
        }
        console.log(res);
        wx.setStorageSync('errorInfo', errorInfo)
        wx.navigateTo({
          url: `/pages/errorDetail/errorDetail?id=${this.properties.errorInfo.deviceId}`,
        })
      })
    }
  }
})
