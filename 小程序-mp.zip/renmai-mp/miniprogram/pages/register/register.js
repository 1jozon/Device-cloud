// miniprogram/pages/register/register.js
const $api = require('../../utils/request.js').request;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    userId: 'admin',
    userPassword: '12345',
    userName: 'test',
    userGender: '男',
    userGenderId: 1,
    genderSelectorShow: false,
    genderActions: [{
        name: '男',
        value: 1,
      },
      {
        name: '女',
        value: 2,
      }
    ],
    userPhone: '12345678910',
    userEmail: 'test@qq.com',
    roleId: 8,
    roleName: '系统管理员',
    roleNameSelectorShow: false,
    roleNameActions: [{
        name: '游客',
        value: 1
      },
      {
        name: '售后',
        value: 2
      },
      {
        name: '销售',
        value: 3
      },
      {
        name: '研发',
        value: 4
      },
      {
        name: '测试',
        value: 5
      },
      {
        name: '质量',
        value: 6
      },
      {
        name: '管理员',
        value: 7
      },
      {
        name: '系统管理员',
        value: 8
      },
    ],
  },

  register() {
    $api('POST', '/rmy/entry/register', {
      userId: this.data.userId,
      userPassword: this.data.userPassword,
      userName: this.data.userName,
      userGender: this.data.userGenderId,
      userPhone: this.data.userPhone,
      userEmail: this.data.userEmail,
      roleId: this.data.roleId
    }).then(res => {
      if (!!res.header['Set-Cookie']) wx.setStorageSync('cookie', res.header['Set-Cookie']);
      console.log(res);
    })
  },

  onActionGenderShow() {
    this.setData({
      genderSelectorShow: true
    })
  },

  onActionGenderClose() {
    this.setData({
      genderSelectorShow: false
    });
  },

  onActionGenderSelect(event) {
    const {
      name,
      value
    } = event.detail;
    this.setData({
      userGender: name,
      userGenderId: value
    });
  },

  onActionShow() {
    this.setData({
      roleNameSelectorShow: true
    });
  },

  onActionClose() {
    this.setData({
      roleNameSelectorShow: false
    });
  },

  onActionSelect(event) {
    const {
      name,
      value
    } = event.detail;
    this.setData({
      roleName: name,
      roleId: value
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})