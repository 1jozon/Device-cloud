// miniprogram/pages/resetPassword/resetPassword.js
const $api = require('../../utils/request.js').request;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    oldPassword: '',
    newPassword: '',
    newPasswordTest: ''
  },

  submit() {
    console.log(typeof this.data.newPasswordTest, this.data.newPasswordTest.length);
    if (this.data.oldPassword.length === 0 || this.data.newPassword.length === 0 || this.data.newPasswordTest.length === 0) {
      wx.showToast({
        title: '请完整填写表单...',
        icon: 'none',
      })
      return;
    }
    if (this.data.newPassword.length < 6 || this.data.newPasswordTest.length < 6) {
      wx.showToast({
        title: '密码长度应该大于6...',
        icon: 'none',
      })
      return;
    }
    if (this.data.newPassword !== this.data.newPasswordTest) {
      wx.showToast({
        title: '两次新密码不一致...',
        icon: 'none',
      })
      return;
    }
    $api('POST', '/rmy/set/changePassword', {
      userId: wx.getStorageSync('userId'),
      oldPassword: this.data.oldPassword,
      newPassword: this.data.newPassword,
    }, true).then(res => {
      console.log(res);
      if (res.data.resultCode === "400") {
        wx.showToast({
          icon: 'none',
          title: res.data.obj,
        })
        return;
      }
      if (res.data.resultCode === "200") {
        wx.showToast({
          icon: 'none',
          title: '密码修改成功',
        })
        wx.redirectTo({
          url: '/pages/login/login',
        })
        return;
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})