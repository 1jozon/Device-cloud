// miniprogram/pages/error/error.js
const $api = require('../../utils/request.js').request;
let current = 1;

let timeout = null;

let errorListTemp = []

Page({

  /**
   * 页面的初始数据
   */
  data: {
    searchId: '',
    errorInstrumentList: [],
    type: "筛选故障",
    actionShow: false,
    actions: [
      {
        name: '未处理',
      },
      {
        name: '已处理',
      },
      {
        name: '全部',
      },
    ]
  },

  searchById(e) {
    const id = e.currentTarget.dataset.id;
    this.setData({
      errorInstrumentList: [],
    }, () => {
      current = 1;
      this.getErrorInstrumentList(10, id);
    })
  },

  getTips(id) {
    $api('POST', `/rmy/instrument/getInstrumentIdForBox`, {
      instrumentId: id,
    }, true).then(res => {
      this.setData({
        tipList: res.data.obj
      })
    })
  },

  getSearchTip(e) {
    if(!!timeout) {
      clearTimeout(timeout);
      timeout = null;
      timeout = setTimeout(() => {
        this.getTips(e.detail);
      }, 500)
    } else {
      timeout = setTimeout(() => {
        this.getTips(e.detail);
      }, 500)
    }
  },

  onShowTipBox() {
    this.setData({
      showTipBox: true
    })
  },

  onCloseTipBox() {
    this.setData({
      showTipBox: false
    })
  },

  getErrorInstrumentList(size = 10, searchId = '') {
    $api('POST', `/rmy/faultRecord/selectByPage/${current}/${size}`, {
      deviceId: searchId,
      userId: wx.getStorageSync('userId'),
    }, true).then(res => {
      // console.log(res.header['Set-Cookie']);
      console.log(res);
      errorListTemp = [...this.data.errorInstrumentList, ...(res.data.obj?.faultRecords || [])];
      this.setData({
        errorList: errorListTemp,
      })
    })
  },

  

  changeType() {
    this.setData({
      actionShow: true,
    })
  },

  onClose() {
    this.setData({ actionShow: false });
  },

  onSelect(event) {
    this.setData({
      type: event.detail.name === '全部' ? '筛选故障' : event.detail.name,
      actionShow: false,
    });
    if(event.detail.name === "未处理") {
      let temp = errorListTemp.filter(item => item.handleStatus === event.detail.name);
      this.setData({
        errorList: temp,
      });
    } else if(event.detail.name === "已处理") {
      let temp = errorListTemp.filter(item => item.handleStatus === event.detail.name);
      this.setData({
        errorList: temp,
      });
    } else {
      this.setData({
        errorList: errorListTemp,
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getErrorInstrumentList()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getErrorInstrumentList()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    current = 1;
    this.getErrorInstrumentList();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    current = current + 1;
    this.getErrorInstrumentList();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})