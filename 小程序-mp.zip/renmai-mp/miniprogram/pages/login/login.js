// miniprogram/pages/login/login.js
const $api = require('../../utils/request.js').request;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    userId: '',
    userPassword: '',
    roleId: 8,
    roleName: '',
    roleNameSelectorShow: false,
    roleNameActions: [{
        name: '游客',
        value: 1
      },
      {
        name: '售后',
        value: 2
      },
      {
        name: '销售',
        value: 3
      },
      {
        name: '研发',
        value: 4
      },
      {
        name: '测试',
        value: 5
      },
      {
        name: '质量',
        value: 6
      },
      {
        name: '管理员',
        value: 7
      },
      {
        name: '系统管理员',
        value: 8
      },
    ],
  },

  login() {
    $api('POST', '/rmy/entry/login', {
      userId: this.data.userId,
      userPassword: this.data.userPassword,
      roleName: this.data.roleName
    }, false).then(res => {
      if (res.data.resultCode === '200') {
        wx.setStorageSync('cookie', res.header['Set-Cookie']);
        wx.setStorageSync('userId', this.data.userId);
        $api('POST', '/rmy/set/getPersonalByMini', {userId: this.data.userId}, true).then(res => {
          wx.setStorageSync('userName', res.data.obj.userName);
          wx.switchTab({
            url: '/pages/index/index',
          });
        })
      } else {
        wx.showToast({
          title: res.data.obj,
          icon: 'none',
        })
      }
      console.log(res);
    })
  },

  onActionShow() {
    this.setData({
      roleNameSelectorShow: true
    });
  },

  onActionClose() {
    this.setData({
      roleNameSelectorShow: false
    });
  },

  onActionSelect(event) {
    const {
      name,
      value
    } = event.detail;
    this.setData({
      roleName: name,
      roleId: value
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})