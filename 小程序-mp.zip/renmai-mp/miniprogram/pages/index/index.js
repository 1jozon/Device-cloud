// miniprogram/pages/index/index.js
const $api = require('../../utils/request.js').request;
let current = 1;

let timeout = null;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    searchId: '',
    instrumentList: [],
    tipList: [],
    showTipBox: false,
  },

  getInstrumentList(size = 10, searchId = '') {
    $api('POST', `/rmy/instrument/selectInstByCondition/${current}/${size}`, {
      instrumentId: searchId,
      userId: wx.getStorageSync('userId')
    }, true).then(res => {
      // console.log(res.header['Set-Cookie']);
      console.log(res.data.obj.list);
      if(res.data.obj.list.length > 0) {
        current = current + 1;
      }
      if(res.data.obj.list.length === 0) {
        wx.showToast({
          icon: 'none',
          title: '暂无更多数据...',
        })
      }
      this.setData({
        instrumentList: [...this.data.instrumentList, ...res.data.obj.list]
      })
    })
  },

  searchById(e) {
    const id = e.currentTarget.dataset.id;
    this.setData({
      instrumentList: [],
    }, () => {
      current = 1;
      this.getInstrumentList(10, id);
    })
  },

  getTips(id) {
    $api('POST', `/rmy/instrument/getInstrumentIdForBox`, {
      instrumentId: id,
    }, true).then(res => {
      this.setData({
        tipList: res.data.obj
      })
    })
  },

  getSearchTip(e) {
    if(!!timeout) {
      clearTimeout(timeout);
      timeout = null;
      timeout = setTimeout(() => {
        this.getTips(e.detail);
      }, 500)
    } else {
      timeout = setTimeout(() => {
        this.getTips(e.detail);
      }, 500)
    }
  },

  onShowTipBox() {
    this.setData({
      showTipBox: true
    })
  },

  onCloseTipBox() {
    this.setData({
      showTipBox: false
    })
  },

  addOne() {
    wx.navigateTo({
      url: '/pages/instrumentAdd/instrumentAdd',
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (!wx.getStorageSync('cookie')) {
      wx.redirectTo({
        url: '/pages/login/login',
      })
    }
    current = 1;
    this.getInstrumentList();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    current = 1;
    this.setData({
      instrumentList: [],
    });
    this.getInstrumentList();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.getInstrumentList();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})