// miniprogram/pages/resetEmail/resetEmail.js
const $api = require('../../utils/request.js').request;
let interval = null;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userEmail: '',
    verifcationCode: '',
  },

  getCode() {
    if (this.data.lock) return;
    const regEmail =
      /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/;
    if (!regEmail.test(this.data.userEmail)) {
      wx.showToast({
        title: '请填写正确的邮箱...',
        icon: 'none',
      })
      return;
    }
    $api('POST', '/rmy/set/getVerificationCode', {
      userId: wx.getStorageSync('userId'),
      userEmail: this.data.userEmail,
    }, true).then(res => {
      console.log(res);
    })
    this.setData({
      timecount: 10,
      lock: true,
    })
    interval = setInterval(() => {
      if (this.data.timecount <= 1) {
        this.setData({
          timecount: 0,
          lock: false,
        })
        clearInterval(interval);
        interval = null;
        return;
      }
      this.setData({
        timecount: this.data.timecount - 1,
      })
    }, 1000)
  },

  submit() {
    if (this.data.userEmail.length === 0 || this.data.verifcationCode.length === 0) {
      wx.showToast({
        title: '请完整填写表单...',
        icon: 'none',
      })
      return;
    }
    const regEmail =
      /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/;
    if (!regEmail.test(this.data.userEmail)) {
      wx.showToast({
        title: '请填写正确的邮箱...',
        icon: 'none',
      })
      return;
    }
    $api('POST', '/rmy/set/updatePersonal', {
      userId: wx.getStorageSync('userId'),
      userEmail: this.data.userEmail,
      verifcationCode: this.data.verifcationCode,
    }, true).then(res => {
      console.log(res);
      if (res.data.resultCode === "200") {
        wx.showToast({
          icon: 'none',
          title: '邮箱修改成功',
        })
        wx.navigateBack({
          delta: 0,
        })
        return;
      } else {
        wx.showToast({
          icon: 'none',
          title: '未知错误',
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    interval = null;
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})