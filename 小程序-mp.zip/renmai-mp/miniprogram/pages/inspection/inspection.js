// miniprogram/pages/inspection/inspection.js
const $api = require('../../utils/request.js').request;
let current = 1;

let timeout = null;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    inspectionList: [],
    tipList: [],
    showTipBox: false,
  },


  searchById(e) {
    const id = e.currentTarget.dataset.id;
    this.setData({
      inspectionList: [],
    }, () => {
      current = 1;
      this.getInspectionList(10, id);
    })
  },

  getTips(id) {
    $api('POST', `/rmy/instrument/getInstrumentIdForBox`, {
      instrumentId: id,
    }, true).then(res => {
      this.setData({
        tipList: res.data.obj
      })
    })
  },

  getSearchTip(e) {
    if(!!timeout) {
      clearTimeout(timeout);
      timeout = null;
      timeout = setTimeout(() => {
        this.getTips(e.detail);
      }, 500)
    } else {
      timeout = setTimeout(() => {
        this.getTips(e.detail);
      }, 500)
    }
  },

  onShowTipBox() {
    this.setData({
      showTipBox: true
    })
  },

  onCloseTipBox() {
    this.setData({
      showTipBox: false
    })
  },

  getInspectionList(size = 10, searchId = '') {
    $api('POST', `/rmy/checkData/getCheckDataByCondition/${current}/${size}`, {
      instrumentId: searchId,
      userId: wx.getStorageSync('userId')
    }, true).then(res => {
      // console.log(res.header['Set-Cookie']);
      console.log(res.data.obj.list);
      if (res.data.obj.list.length > 0) {
        current = current + 1;
      }
      if (res.data.obj.list.length === 0) {
        wx.showToast({
          icon: 'none',
          title: '暂无更多数据...',
        })
      }
      this.setData({
        inspectionList: [...this.data.inspectionList, ...res.data.obj.list]
      })
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    current = 1;
    this.getInspectionList();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    current = 1;
    this.setData({
      inspectionList: [],
    });
    this.getInspectionList();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})