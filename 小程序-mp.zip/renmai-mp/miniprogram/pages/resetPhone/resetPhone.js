// miniprogram/pages/resetPhone/resetPhone.js
const $api = require('../../utils/request.js').request;
let interval = null;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    userPhone: '',
    verifcationCode: '',
    lock: false,
    timecount: 0,
  },

  getCode() {
    if (this.data.lock) return;
    const regMobile =
      /^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/;
    if (!regMobile.test(this.data.userPhone)) {
      wx.showToast({
        title: '请填写正确的手机号...',
        icon: 'none',
      })
      return;
    }
    $api('POST', '/rmy/set/getVerificationCode', {
      userId: wx.getStorageSync('userId'),
      userPhone: this.data.userPhone,
    }, true).then(res => {
      console.log(res);
    })
    this.setData({
      timecount: 10,
      lock: true,
    })
    interval = setInterval(() => {
      if (this.data.timecount <= 1) {
        interval = null;
        this.setData({
          timecount: 0,
          lock: false,
        })
        return;
      }
      this.setData({
        timecount: this.data.timecount - 1,
      })
    }, 1000)
  },

  submit() {
    if (this.data.userPhone.length === 0 || this.data.verifcationCode.length === 0) {
      wx.showToast({
        title: '请完整填写表单...',
        icon: 'none',
      })
      return;
    }
    const regMobile =
      /^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/;
    if (!regMobile.test(this.data.userPhone)) {
      wx.showToast({
        title: '请填写正确的手机号...',
        icon: 'none',
      })
      return;
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    interval = null;
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})