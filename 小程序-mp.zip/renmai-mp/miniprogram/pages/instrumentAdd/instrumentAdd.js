// miniprogram/pages/instrumentAdd/instrumentAdd.js
const $api = require('../../utils/request.js').request;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    instrumentId: "",
    instrumentModel: "",
    instrumentAddress: "",
    instrumentDate: "",
    instrumentInstallerId: wx.getStorageSync('userId') || '',
    instrumentInstallerName: "",
    instrumentMaintainerId: "",
    instrumentMaintainerName: "",
    instrumentMaintainerPhone: "",
    hospitalName: "",
    calendarShow: false,
  },

  onDisplayCalendar() {
    this.setData({
      calendarShow: true,
    })
  },

  onCloseCalendar() {
    this.setData({
      calendarShow: false,
    })
  },

  formatDate(date) {
    date = new Date(date);
    return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
  },

  onConfirmCalendar(event) {
    this.setData({
      calendarShow: false,
      instrumentDate: this.formatDate(event.detail),
    })
  },

  submit() {
    if (!this.data.instrumentId || !this.data.instrumentModel || !this.data.instrumentAddress || !this.data.instrumentDate || !this.data.instrumentInstallerId ||
      !this.data.instrumentInstallerName || !this.data.instrumentMaintainerId || !this.data.instrumentMaintainerName || !this.data.instrumentMaintainerPhone || !this.data.hospitalName) {
      wx.showToast({
        title: '请完整填写表单！',
        icon: 'none',
      });
      return;
    }
    $api('POST', '/rmy/instrument/registerInstrument', {
      instrumentId: this.data.instrumentId,
      instrumentModel: this.data.instrumentModel,
      instrumentAddress: this.data.instrumentAddress,
      instrumentDate: this.data.instrumentDate,
      instrumentInstallerId: this.data.instrumentInstallerId,
      instrumentInstallerName: this.data.instrumentInstallerName,
      instrumentMaintainerId: this.data.instrumentMaintainerId,
      instrumentMaintainerName: this.data.instrumentMaintainerName,
      instrumentMaintainerPhone: this.data.instrumentMaintainerPhone,
      hospitalName: this.data.hospitalName,
    }, true).then(() => {
      wx.showToast({
        title: '处理提交成功！',
        icon: 'none',
      })
      setTimeout(() => {
        wx.navigateBack()
      }, 1000);
    }).catch(err => console.error(err));
  },

  getMaintenceUsers() {
    return $api('POST', '/rmy/manager/getMaintenceUsers', {
      userId: this.data.instrumentMaintainerId
    }, true).then(res => {
      const index = res.data.obj.list.findIndex(item => item.userId === this.data.instrumentMaintainerId);
      if (index !== -1) {
        return res.data.obj.list[index];
      } else {
        return res.data.obj.list[0];
      }
    })
  },

  setMaintainerInfo() {
    this.getMaintenceUsers().then(info => {
      this.setData({
        instrumentMaintainerId: info.userId,
        instrumentMaintainerName: info.userName,
        instrumentMaintainerPhone: info.userPhone,
      })
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  //读取二维码信息和实时日志
  onLoad: function (query) {
    const log = require("../../log.js")
    //scene参数
    const scene = decodeURIComponent(query.scene)
    //设备id
    var id = scene.split('&')[0]
    id = id.substr(id.indexOf('=') + 1, id.length)
    //设备类型
    var model = scene.split('&')[1]
    model = model.substr(model.indexOf('=') + 1, model.length)
    this.setData({
      instrumentId: id,
      instrumentModel: model
    })
    console.log(scene);
    log.info(query.scene)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})