const baseURL = 'http://121.40.104.60:8084';

const request = (method, url, data, json = true) => {
  return new Promise(function (resolve, reject) {
    let token = wx.getStorageSync('token')
    let header = {
      // application/x-www-form-urlencoded;
      'content-type': json ? 'application/json' : 'application/x-www-form-urlencoded',
      'cookie': wx.getStorageSync('cookie') || '',
    };
    console.log(header);
    if (token != '') {
      header['Authorization'] = token
    }
    wx.request({
      url: baseURL + url,
      method: method,
      data: method.toUpperCase === 'POST' ? JSON.stringify(data) : data,
      header: header,
      success: res => {
        if (res.statusCode === 200) {
          resolve(res)
        } else {
          wx.clearStorageSync();
          wx.redirectTo({
            url: '/pages/login/login',
          })
          reject(res.data.msg || res.data.message)
        }
      },
      fail: err => {
        reject(err.errMsg)
      }
    })
  })
}

module.exports = {
  request
}