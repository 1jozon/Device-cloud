package cn.rmy.dao;

import cn.rmy.common.beans.checkData.CheckData;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CheckDataDao extends BaseMapper<CheckData> {
}
