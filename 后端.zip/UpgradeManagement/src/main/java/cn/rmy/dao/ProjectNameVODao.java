package cn.rmy.dao;

import cn.rmy.beans.dto.ProjectNameVO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProjectNameVODao extends BaseMapper<ProjectNameVO> {
}
