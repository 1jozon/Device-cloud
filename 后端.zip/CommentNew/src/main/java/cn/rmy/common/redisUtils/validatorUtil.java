package cn.rmy.common.redisUtils;

/**
 * 一句话功能描述.
 * 项目名称:  校验注解
 * 包:
 * 类名称:
 * 类描述:   类功能详细描述
 * 创建人:
 * 创建时间:
 */
public class validatorUtil {


    /**
     * 用于手机号码验证————自定义注解
     * @param mobile
     * @return
     */
    public static boolean isMobile(String mobile){
        /**
            具体的比如说是号码的正则校验函数—————用于自定义注解中使用
        */
        return false;

    }
}
