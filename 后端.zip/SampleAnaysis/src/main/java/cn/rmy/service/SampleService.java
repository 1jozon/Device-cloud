package cn.rmy.service;



public interface SampleService {

}
