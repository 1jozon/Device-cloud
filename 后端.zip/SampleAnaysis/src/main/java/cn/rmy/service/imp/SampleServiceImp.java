package cn.rmy.service.imp;

import cn.rmy.service.SampleService;
import org.springframework.stereotype.Service;

@Service
public class SampleServiceImp implements SampleService {
}
