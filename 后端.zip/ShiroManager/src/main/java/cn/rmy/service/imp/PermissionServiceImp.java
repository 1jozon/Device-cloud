package cn.rmy.service.imp;

import cn.rmy.service.PermissionService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 权限服务
 *
 * @author chu
 * @date 2021/11/11
 */
@Service
@Transactional
public class PermissionServiceImp implements PermissionService {


}
