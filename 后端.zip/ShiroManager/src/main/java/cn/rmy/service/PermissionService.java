package cn.rmy.service;

/**
 * 权限服务
 *
 * @author chu
 * @date 2021/11/11
 */
public interface PermissionService {
}
